API_URL = "http://123.157.247.187:31000"  # MinerU 服务地址

# 自定义CSS样式
CUSTOM_CSS = """
.container {
    max-width: 800px !important;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 1rem !important;
    padding-right: 1rem !important;
}
.header {
    text-align: center !important;
    margin-bottom: 2rem !important;
}
.header h1 {
    font-size: 2.5rem !important;
    margin-bottom: 0.5rem !important;
}
.header p {
    font-size: 1.1rem !important;
    color: #666 !important;
}
.upload-section {
    background-color: #f8f9fa !important;
    border-radius: 10px !important;
    padding: 1.5rem !important;
    margin-bottom: 1.5rem !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1) !important;
}
.download-section {
    background-color: #f0f8ff !important;
    border-radius: 10px !important;
    padding: 1.5rem !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1) !important;
}
.footer {
    text-align: center !important;
    margin-top: 2rem !important;
    font-size: 0.9rem !important;
    color: #666 !important;
}
.options-row {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
}
"""
